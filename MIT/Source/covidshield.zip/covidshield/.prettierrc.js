module.exports = {
  arrowParens: 'avoid',
  singleQuote: true,
  bracketSpacing: false,
  trailingComma: 'all',
  printWidth: 120,
};
