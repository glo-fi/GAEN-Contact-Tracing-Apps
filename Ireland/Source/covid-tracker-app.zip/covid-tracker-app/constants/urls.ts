import {API_HOST} from 'react-native-dotenv';

export const urls = {
  api: API_HOST
};
