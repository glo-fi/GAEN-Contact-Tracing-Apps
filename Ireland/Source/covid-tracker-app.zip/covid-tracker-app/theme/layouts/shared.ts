export const SPACING_HORIZONTAL = 20;
export const SPACING_TOP = 16;
export const SPACING_BOTTOM = 8;
