package de.rki.coronawarnapp.nearby

object ResolutionRequestCodeConstants {
    const val REQUEST_CODE_START_EXPOSURE_NOTIFICATION_CODE = 1111
    const val REQUEST_CODE_GET_TEMP_EXPOSURE_KEY_HISTORY_CODE = 2222
}
