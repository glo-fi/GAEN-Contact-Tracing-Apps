package de.rki.coronawarnapp.transaction

/**
 * An Interface used by Transactions to define different states during execution.
 *
 * @see Transaction
 */
interface TransactionState
