package de.rki.coronawarnapp.util

object AssetConstants {
    // Path to android assets
    const val ANDROID_ASSET_PATH = "file:////android_asset/"
}
