package de.rki.coronawarnapp.ui.submission

object TanConstants {
    const val MAX_LENGTH = 10
    val ALPHA_NUMERIC_CHARS = ('a'..'z').plus('A'..'Z').plus('0'..'9')
}
