package de.rki.coronawarnapp.storage

const val DATABASE_NAME = "coronawarnapp-db"
