package hr.miz.evidencijakontakata.Listeners;

public interface IEditTextDoneListener {
    void clickKeyboardDone();
}
