package hr.miz.evidencijakontakata.Listeners;

public interface INoNetworkListener {
    void onClickRefresh();
}
