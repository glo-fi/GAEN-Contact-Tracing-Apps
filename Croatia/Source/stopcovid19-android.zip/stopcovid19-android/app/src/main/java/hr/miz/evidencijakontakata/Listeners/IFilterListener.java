package hr.miz.evidencijakontakata.Listeners;


public interface IFilterListener {
    void getNewValue(Object object);
}
