package hr.miz.evidencijakontakata.Utilities;

public class GlobalEnvironment {
    public String globalURL;
}
