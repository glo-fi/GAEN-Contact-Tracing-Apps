package hr.miz.evidencijakontakata.Listeners;

public interface IPermissionDialog {
    void onResult(boolean isAllowed);
}
