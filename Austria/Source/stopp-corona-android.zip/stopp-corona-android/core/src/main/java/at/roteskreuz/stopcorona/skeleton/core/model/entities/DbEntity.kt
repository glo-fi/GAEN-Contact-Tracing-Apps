package at.roteskreuz.stopcorona.skeleton.core.model.entities

/**
 * Interface for app DB data classes (entities).
 */
interface DbEntity