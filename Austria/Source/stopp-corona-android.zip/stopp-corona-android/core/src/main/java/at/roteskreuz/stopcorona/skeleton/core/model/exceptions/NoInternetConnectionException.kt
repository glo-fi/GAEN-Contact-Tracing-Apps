package at.roteskreuz.stopcorona.skeleton.core.model.exceptions

/**
 * Exception indicating that user does not have internet connection.
 */
object NoInternetConnectionException : Exception()