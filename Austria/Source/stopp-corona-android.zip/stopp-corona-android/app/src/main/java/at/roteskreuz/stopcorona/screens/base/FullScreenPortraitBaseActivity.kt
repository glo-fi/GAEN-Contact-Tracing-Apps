package at.roteskreuz.stopcorona.screens.base

/**
 * Activity with fullscreen theme.
 */
open class FullScreenPortraitBaseActivity : CoronaPortraitBaseActivity()