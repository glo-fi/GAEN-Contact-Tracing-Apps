package at.roteskreuz.stopcorona

/**
 * Release initialization.
 */
fun App.onPostCreateFlavourDependent() {
    // logging
}