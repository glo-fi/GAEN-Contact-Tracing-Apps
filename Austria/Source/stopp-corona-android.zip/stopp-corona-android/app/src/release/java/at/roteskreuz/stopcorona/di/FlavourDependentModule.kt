package at.roteskreuz.stopcorona.di

import org.koin.dsl.module.module

/**
 * Module for providing flavour dependent dependencies.
 */
internal val flavourDependentModule = module {
    // do nothing
}
