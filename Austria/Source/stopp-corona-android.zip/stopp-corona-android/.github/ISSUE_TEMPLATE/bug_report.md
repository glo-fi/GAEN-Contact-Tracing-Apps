---
name: 🐞 Bug Report
about: Report a bug or problem in the app
---

## Description

[What happened]

## Reproduction steps

1. [First step]
2. [Second step]
3. etc.

Additional helpful information:

- Screenshots
- Version of the app

## What did you expect

[What you think should have happened]

