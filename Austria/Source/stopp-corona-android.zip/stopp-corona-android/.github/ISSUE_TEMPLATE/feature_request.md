---
name: 🚀 Feature Requests
about: Feature requests and recommendations.
---

Describe roughly your feature request and why you think it's a good idea.
