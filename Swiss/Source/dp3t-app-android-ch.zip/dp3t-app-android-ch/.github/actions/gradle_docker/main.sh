#!/bin/sh

cd $GITHUB_WORKSPACE
gradle $1