/*
 * Copyright (c) 2020 Ubique Innovation AG <https://www.ubique.ch>
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * SPDX-License-Identifier: MPL-2.0
 */

package ch.admin.bag.dp3t.util;

import android.app.Application;
import android.app.Activity;
import android.os.Bundle;

/**
 * Empty implementation of {@link Application.ActivityLifecycleCallbacks}.
 * Can be used to observe {@link Activity} lifecycle events.
 * @see Application#registerActivityLifecycleCallbacks(Application.ActivityLifecycleCallbacks)
 */
public class ActivityLifecycleCallbacksAdapter implements Application.ActivityLifecycleCallbacks {

	@Override
	public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
	}

	@Override
	public void onActivityStarted(Activity activity) {
	}

	@Override
	public void onActivityResumed(Activity activity) {
	}

	@Override
	public void onActivityPaused(Activity activity) {
	}

	@Override
	public void onActivityStopped(Activity activity) {
	}

	@Override
	public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
	}

	@Override
	public void onActivityDestroyed(Activity activity) {
	}

}