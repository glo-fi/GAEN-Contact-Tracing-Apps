package lv.spkc.apturicovid.ui.widget.radiobutton

data class RadioButtonUiModel(
    var text: String = ""
)