package pl.gov.mc.protegosafe.domain.model

class TemporaryIDItem(
    val startTime: Long,
    val tempID: String,
    val expiryTime: Long
)
