package pl.gov.mc.protegosafe.domain.model

class ClearItem(
    val clearBtData: Boolean
)
