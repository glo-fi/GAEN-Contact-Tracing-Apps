package pl.gov.mc.protegosafe.domain.model

data class ActivityResult(val request: ActivityRequest, val isResultOk: Boolean)
