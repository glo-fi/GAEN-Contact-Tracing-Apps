package pl.gov.mc.protegosafe.domain.model

enum class PushNotificationTopic {
    UNKNOWN,
    MAIN,
    DAILY;
}
