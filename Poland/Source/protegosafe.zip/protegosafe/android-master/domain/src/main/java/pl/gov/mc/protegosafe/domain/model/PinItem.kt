package pl.gov.mc.protegosafe.domain.model

data class PinItem(val pin: String)
