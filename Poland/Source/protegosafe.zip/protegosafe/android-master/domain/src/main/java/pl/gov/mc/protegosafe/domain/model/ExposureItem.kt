package pl.gov.mc.protegosafe.domain.model

class ExposureItem(
    val date: Long,
    val durationInMinutes: Int,
    val riskScore: Int
)
