package pl.gov.mc.protegosafe.domain.model

data class TriageItem(
    val timestamp: Long
)
