package pl.gov.mc.protegosafe.domain.repository

interface CertificatePinningRepository {
    fun initialize()
}
