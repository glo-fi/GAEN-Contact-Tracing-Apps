## Lista osób które podpisały [oświadczenie o udzieleniu licencji](CONTRIBUTING.md#Oświadczenie-o-udzieleniu-licencji) i wprowadziły zmiany w projekcie:

Imię i nazwisko        | GitHub ID                                                 | Komponenty
---------------------- | ----------------------------------------------------------| -----------------------------
Jakub Lipiński         | [jakublipinski](https://github.com/jakublipinski)         | backend, specs
Adam Dobrawy           | [ad-m](https://github.com/ad-m)                           | specs
Piotr Kalinowski       | [optimusbits](https://github.com/optimusbits)             | ios   
Oskar Hinc             | [oskarhinc](https://github.com/oskarhinc)                 | specs
Maciej Janusz          | [maciekjanusz](https://github.com/maciekjanusz)           | android
Tobiasz Olejnik        | [tobiaszolejnik](https://github.com/tobiaszolejnik)       | android
Błażej Biesiada        | [bejo](https://github.com/bejo)                           | ios
Mikołaj Lewandowski    | [mikolevy](https://github.com/mikolevy)                   | specs
Bartosz Paszcza        | [bpaszcza](https://github.com/bpaszcza)                   | specs
Wojciech Dziwulski     | [wojdziw](https://github.com/wojdziw)                     | specs
Wojciech Szkutnik      | [wojtekszkutnik](https://github.com/wojtekszkutnik)       | specs
Michał Kuchtar         | [michalkuchtar](https://github.com/michalkuchtar)         | android
Tomasz Heimowski       | [theimowski](https://github.com/theimowski)               | android
Adam Kozłowski         | [vetin4ri](https://github.com/vetin4ri)                   | backend
Jarosław Smiejczak     | [jotes](https://github.com/jotes)                         | backend
Paweł Kleczkowski      | [pkleczko](https://github.com/pkleczko)                   | android
Kamil Pawlak           | [qLb](https://github.com/qLb)                             | specs,backend	
Artur Słomowski        | [tarvald](https://github.com/tarvald)                     | specs,backend
Łukasz Dąbrzalski      | [lukaszdabrzalski](https://github.com/lukaszdabrzalski)   | web
Rafał Małczyński       | [RMalczynski](https://github.com/RMalczynski)             | ios
Łukasz Szyszkowski     | [lukasz-szyszkowski](https://github.com/RMalczynski)      | ios
Wojciech Nasiłowski    | [wnasilowski](https://github.com/wnasilowski)             | android
Tomasz Molenda         | [TomaszMolenda](https://github.com/TomaszMolenda)         | web
Jakub Rękas            | [jakubrekas1](https://github.com/jakubrekas1)             | web
Mateusz Andruszko      | [mateuszandruszko](https://github.com/mateuszandruszko)   | web
Michał Poteralski      | [MikeSPtr](https://github.com/MikeSPtr)                   | android
Oleksandr Katrych      | [OKatrych](https://github.com/OKatrych)                   | android
Wojciech Brydak        | [wbrydak](https://github.com/wbrydak)                    | specs
