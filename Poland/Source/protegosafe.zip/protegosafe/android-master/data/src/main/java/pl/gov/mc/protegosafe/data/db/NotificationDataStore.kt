package pl.gov.mc.protegosafe.data.db

class NotificationDataStore {
    var notificationData: String = ""
}
