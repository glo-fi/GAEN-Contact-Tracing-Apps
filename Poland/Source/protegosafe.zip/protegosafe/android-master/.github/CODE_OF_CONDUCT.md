## Code of Conduct

This Code of Conduct is adapted from the [CNCF Code of Conduct](https://github.com/cncf/foundation/blob/master/code-of-conduct.md).

Instances of abusive, harassing, or otherwise unacceptable behavior across GitHub [SafeSafe-app](https://github.com/SafeSafe-app) organization may be reported by contacting the SafeSafe-app Code of Conduct Committee via community@safesafe.app. For other projects, please contact apropriate project maintainer or our mediator - Mateusz Romanów mr@safesafe.app.
