## Contributing
Our guidelines are mostly located around `.github/` directory of the project.

### ToC for contributors
- [Code of Conduct](https://github.com/SafeSafe-app/gh-spec/blob/master/.github/CODE_OF_CONDUCT.md)
- [Issues & Support](https://github.com/SafeSafe-app/gh-spec/blob/master/.github/SUPPORT.md)
- [License](https://github.com/SafeSafe-app/gh-spec/blob/master/LICENSE)
- [Security](https://github.com/SafeSafe-app/gh-spec/blob/master/.github/SECURITY.md)
- [Pull request](https://github.com/SafeSafe-app/gh-spec/blob/master/.github/PULL_REQUEST_TEMPLATE/README.md)
