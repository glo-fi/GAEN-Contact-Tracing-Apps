package uk.nhs.nhsx.covid19.android.app.common

interface BluetoothAdapterApi {
    fun isEnabled(): Boolean
}
