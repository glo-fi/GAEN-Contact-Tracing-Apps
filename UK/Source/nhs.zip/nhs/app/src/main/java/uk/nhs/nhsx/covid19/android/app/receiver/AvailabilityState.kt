package uk.nhs.nhsx.covid19.android.app.receiver

enum class AvailabilityState {
    ENABLED, DISABLED
}
