package uk.nhs.nhsx.covid19.android.app.status

import androidx.fragment.app.Fragment

class DebugFragment : Fragment()
