---
name: Feature request
about: Project Suggestions
---

Thank you for your interest in this project

We welcome feedback about the Test and Trace App, and this can be sent to us via the 
https://faq.covid19.nhs.uk/create-case/ page on the website.



