## [1.0.11](https://github.com/Path-Check/covid-safe-paths/compare/v0.5.4...1.0.11) (2020-05-13)


### Reverts

* Revert "Fix missing settings icon on iOS 12.0.x (#643)" (#650) ([363864a](https://github.com/Path-Check/covid-safe-paths/commit/363864a196c38a727a17b0a892648e7883794757)), closes [#643](https://github.com/Path-Check/covid-safe-paths/issues/643) [#650](https://github.com/Path-Check/covid-safe-paths/issues/650)



## [0.5.4](https://github.com/Path-Check/covid-safe-paths/compare/v0.5.3...v0.5.4) (2020-03-23)



## [0.5.3](https://github.com/Path-Check/covid-safe-paths/compare/v0.5.2...v0.5.3) (2020-03-20)



