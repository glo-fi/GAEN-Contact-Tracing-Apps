
public typealias GenericResult = Result<Void>
public typealias GenericCompletion = (GenericResult) -> Void
