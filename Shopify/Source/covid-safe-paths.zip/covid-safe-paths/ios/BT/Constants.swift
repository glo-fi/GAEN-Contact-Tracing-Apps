enum Constants {
  static let intervalsPerRollingPeriod: Int = 144
  static let exposureLifetimeHours: Int = 336
  static let dailyFileProcessingCapacity: Int = 15
}
