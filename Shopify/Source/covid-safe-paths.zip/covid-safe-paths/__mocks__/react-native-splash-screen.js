export default {
  show: jest.fn(),
  hide: jest.fn(),
};
