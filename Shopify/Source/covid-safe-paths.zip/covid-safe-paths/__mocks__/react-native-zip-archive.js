export default {
  unzip: jest.fn(),
  subscribe: jest.fn(),
};
