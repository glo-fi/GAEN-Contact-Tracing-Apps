export default {
  configure: jest.fn(),
};
