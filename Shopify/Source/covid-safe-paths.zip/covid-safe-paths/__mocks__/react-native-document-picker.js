export default {
  pick: jest.fn(),
  pickMultiple: jest.fn(),
  isCancel: jest.fn(),
};
