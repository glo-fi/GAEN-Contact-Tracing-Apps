export default {
  FLAG_FOO_BAR: 'true',
  TRACING_STRATEGY: 'gps',
};
