export default require('@react-native-community/async-storage/jest/async-storage-mock');
