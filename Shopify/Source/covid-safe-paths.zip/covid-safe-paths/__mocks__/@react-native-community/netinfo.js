export default {
  configure: jest.fn(),
  fetch: jest.fn(),
};
