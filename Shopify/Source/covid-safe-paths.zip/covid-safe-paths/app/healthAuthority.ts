export interface HealthAuthority {
  name: string;
}
