export const APPSTORE_URL = 'itms-apps://itunes.apple.com/us/app/id1508266966';
export const PLAYSTORE_URL = 'market://details?id=org.pathcheck.covidsafepaths';
export const VERSION_URL =
  'https://rawcdn.githack.com/Path-Check/covid-safe-paths/master/versions.yaml';
export const YAML_MANDATORY_VERSION_KEY = 'mandatory upgrade version';
export const YAML_LATEST_VERSION_KEY = 'upgrade version';
