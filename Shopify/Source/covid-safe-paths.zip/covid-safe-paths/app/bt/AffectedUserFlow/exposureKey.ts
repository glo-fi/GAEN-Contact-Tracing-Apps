export interface ExposureKey {
  key: string;
  rollingPeriod: number;
  rollingStartNumber: number;
  transmissionRisk: number;
}
