export function GetStoreData(data) {
  return new Promise((resolve) => {
    resolve(data);
  });
}

export function SetStoreData() {
  return new Promise((resolve) => {
    resolve({});
  });
}
