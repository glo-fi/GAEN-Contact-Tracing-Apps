export const location1 = {
  latitude: 40.7432137,
  longitude: -74.2637634,
  time: '1586354152762',
};
export const location2 = {
  latitude: 40.7442137,
  longitude: -74.2647634,
  time: '1586283593663',
};
export const location3 = {
  latitude: 40.7230026,
  longitude: -74.2961459,
  time: '1586358895000',
};
export const location4 = {
  latitude: 40.7130026,
  longitude: -74.2861459,
  time: '1586358894000',
};
