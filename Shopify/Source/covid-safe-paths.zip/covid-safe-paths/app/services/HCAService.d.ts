import { HCAService as service } from './HCAService';

export const HCAService = service;
