import Config from 'react-native-config';

export const isGPS = Config.TRACING_STRATEGY === 'gps';
