import homeScreen from './Home';

const HomeScreen: () => JSX.Element = homeScreen;

export default HomeScreen;
