import { FunctionComponent } from 'react';

import exportComplete from './ExportComplete';

const ExportComplete: FunctionComponent = exportComplete;

export default ExportComplete;
