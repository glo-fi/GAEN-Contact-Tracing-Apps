import { FunctionComponent } from 'react';

import exportSelectHA from './ExportSelectHA';

const ExportSelectHA: FunctionComponent = exportSelectHA;

export default ExportSelectHA;
