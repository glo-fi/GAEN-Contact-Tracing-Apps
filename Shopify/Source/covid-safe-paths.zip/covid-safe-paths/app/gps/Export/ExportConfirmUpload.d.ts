import { FunctionComponent } from 'react';

import exportConfirmUpload from './ExportConfirmUpload';

const ExportConfirmUpload: FunctionComponent = exportConfirmUpload;

export default ExportConfirmUpload;
