import { FunctionComponent } from 'react';

import exportLocationConsent from './ExportLocationConsent';

const ExportLocationConsent: FunctionComponent = exportLocationConsent;

export default ExportLocationConsent;
