import { FunctionComponent } from 'react';

import exportIntro from './ExportIntro';

const ExportIntro: FunctionComponent = exportIntro;

export default ExportIntro;
