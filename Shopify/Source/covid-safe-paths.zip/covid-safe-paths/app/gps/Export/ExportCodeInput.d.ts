import { FunctionComponent } from 'react';

import exportCodeInput from './ExportCodeInput';

const ExportCodeInput: FunctionComponent = exportCodeInput;

export default ExportCodeInput;
