import { FunctionComponent } from 'react';

import exportPublishConsent from './ExportPublishConsent';

const ExportPublishConsent: FunctionComponent = exportPublishConsent;

export default ExportPublishConsent;
