import { Main } from '../views/Main';

export default Main;
