import { createContext } from 'react';

export const AnswersContext = createContext();
export const SurveyContext = createContext();
export const AssessmentNavigationContext = createContext();
