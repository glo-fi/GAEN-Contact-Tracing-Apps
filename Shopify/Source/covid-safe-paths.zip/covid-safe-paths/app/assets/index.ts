import { Images } from './images';
import { Icons } from './svgs';

export { Icons, Images };
