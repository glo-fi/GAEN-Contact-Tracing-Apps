export const MoreActive = `<svg width="22" height="6" viewBox="0 0 22 6" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="3.22461" cy="3" r="2" fill="#FFFFFF" stroke="#FFFFFF"/>
<circle cx="11.2246" cy="3" r="2" fill="#FFFFFF" stroke="#FFFFFF"/>
<circle cx="19.2246" cy="3" r="2" fill="#FFFFFF" stroke="#FFFFFF"/>
</svg>`;

export const MoreInactive = `<svg width="22" height="6" viewBox="0 0 22 6" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="3.22461" cy="3" r="2" fill="#A5AFFB" stroke="#A5AFFB"/>
<circle cx="11.2246" cy="3" r="2" fill="#A5AFFB" stroke="#A5AFFB"/>
<circle cx="19.2246" cy="3" r="2" fill="#A5AFFB" stroke="#A5AFFB"/>
</svg>`;
