export const HomeActive = `<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M1 21V9.8462L11 1.3145L21 9.8462V21H14.9615V15.6538C14.9615 13.4659 13.1879 11.6923 11 11.6923C8.8121 11.6923 7.03846 13.466 7.03846 15.6538V21H1Z" fill="white" stroke="white" stroke-width="2"/>
</svg>`;

export const HomeInactive = `<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M1 21V9.8462L11 1.3145L21 9.8462V21H14.9615V15.6538C14.9615 13.4659 13.1879 11.6923 11 11.6923C8.8121 11.6923 7.03846 13.466 7.03846 15.6538V21H1Z" stroke="#A5AFFB" stroke-width="2"/>
</svg>`;
