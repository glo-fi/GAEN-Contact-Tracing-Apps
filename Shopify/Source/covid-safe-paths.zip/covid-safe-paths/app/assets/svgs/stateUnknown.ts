export default `<svg width="850" height="850" viewBox="0 0 850 850" fill="none" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient x1="100%" y1="50%" x2="2.20122466%" y2="50%" id="linearGradient-1">
        <stop stop-color="#DBDBDB" offset="0%"></stop>
        <stop stop-color="#B7B7B7" offset="100%"></stop>
    </linearGradient>
  </defs>
  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
  <g id="No-Data-Match">
      <circle id="Oval" stroke="#FFFFFF" opacity="0.2" cx="425" cy="425" r="85.5"></circle>
      <circle id="Oval" stroke="#FFFFFF" opacity="0.2" cx="425" cy="425" r="149.5"></circle>
      <circle id="Oval" stroke="#FFFFFF" opacity="0.2" cx="425" cy="425" r="217.5"></circle>
      <circle id="Oval" stroke="#FFFFFF" opacity="0.2" cx="425" cy="425" r="283.5"></circle>
      <circle id="Oval" stroke="#FFFFFF" opacity="0.2" cx="425" cy="425" r="352.5"></circle>
      <circle id="Oval" stroke="#FFFFFF" opacity="0.2" cx="425" cy="425" r="424.5"></circle>
      <path d="M425,465 C447.091,465 465,447.091 465,425 C465,402.909 447.091,385 425,385 C402.909,385 385,402.909 385,425 C385,447.091 402.909,465 425,465 Z" id="Path" fill="#FFFFFF" fill-rule="nonzero"></path>
      <path d="M425,457 C442.673,457 457,442.673 457,425 C457,407.327 442.673,393 425,393 C407.327,393 393,407.327 393,425 C393,442.673 407.327,457 425,457 Z" id="Path" fill="url(#linearGradient-1)" fill-rule="nonzero"></path>
      <circle id="Oval" stroke="#FFFFFF" stroke-width="3" cx="425" cy="425" r="12"></circle>
  </g>
  </g>
</svg>`;
