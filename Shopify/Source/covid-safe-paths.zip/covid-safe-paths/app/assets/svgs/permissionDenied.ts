export default `<svg width="41" height="41" viewBox="0 0 41 41" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="20.5" cy="20.5" r="20.5" fill="#FF5656"/>
<path d="M20.5 8C13.6075 8 8 13.6078 8 20.5003C8 27.3925 13.6075 33 20.5 33C27.3925 33 33 27.3925 33 20.5003C33 13.6078 27.3922 8 20.5 8ZM20.5 30.1875C15.1497 30.1875 10.8125 25.8506 10.8125 20.5003C10.8125 15.1497 15.1497 10.8125 20.5 10.8125C25.85 10.8125 30.1875 15.1497 30.1875 20.5003C30.1875 25.8506 25.85 30.1875 20.5 30.1875Z" fill="white"/>
<line x1="25.2666" y1="16.1213" x2="16.3879" y2="25" stroke="white" stroke-width="3" stroke-linecap="round"/>
<line x1="1.5" y1="-1.5" x2="14.0563" y2="-1.5" transform="matrix(0.707107 0.707107 0.707107 -0.707107 16 14)" stroke="white" stroke-width="3" stroke-linecap="round"/>
</svg>`;
