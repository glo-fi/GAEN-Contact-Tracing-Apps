export default `
<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.52 2.707a1 1 0 00-1.415 0L5.25 8.563 2.895 6.207a1 1 0 00-1.415 0l-.773.773a1 1 0 000 1.415l3.836 3.835a1 1 0 001.414 0l7.336-7.335a1 1 0 000-1.415l-.773-.773z" fill="#fff"/></svg>`;
